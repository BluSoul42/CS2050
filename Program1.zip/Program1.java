// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
//Ivan Soto
import java.util.Scanner;

public class Program1 {
    public static void main(String[] args) {
        try {
            Scanner scanner = new Scanner(System.in);

            // Create an array to store 4 Album objects
            Album[] albums = new Album[4];

            for (int i = 0; i < 3; i++) {
                try {
                    System.out.println("Enter details for Album " + (i + 1) + ":");
                    System.out.print("Title: ");
                    String title = scanner.nextLine();
                    System.out.print("Performer: ");
                    String performer = scanner.nextLine();
                    System.out.print("Genre: ");
                    String genre = scanner.nextLine();
                    System.out.print("Number of Songs: ");
                    int numSongs = scanner.nextInt();
                    scanner.nextLine(); // Consume the newline character

                    // Create a new Album object with the provided details
                    albums[i] = new Album(title, performer, genre, numSongs);

                    // Display album information
                    System.out.println("\nAlbum " + (i + 1) + " Information:\n" + albums[i]);
                } catch (Exception e) {
                    System.out.println("Error creating album: " + e.getMessage());
                }
            }

            scanner.close();
        } catch (Exception e) {
            System.out.println("Error in the program: " + e.getMessage());
        }
    }
}

