//Ivan Soto
public class Album {
    private String title;
    private String performer;
    private String genre;
    private int numSongs;

    // Default constructor
    public Album() {
        try {
            this.title = "Renaissance";
            this.performer = "Beyonce";
            this.genre = "easy listening";
            this.numSongs = 10;
        } catch (Exception e) {
            System.out.println("Error creating default album: " + e.getMessage());
        }
    }

    // Parameterized constructor
    public Album(String title, String performer, String genre, int numSongs) {
        try {
            this.title = title;
            this.performer = performer;
            // Check if the genre is valid, if not, set it to "easy listening"
            if (isValidGenre(genre)) {
                this.genre = genre;
            } else {
                this.genre = "easy listening";
            }
            // Ensure numSongs is at least 10
            if (numSongs < 10) {
                this.numSongs = 10;
            } else {
                this.numSongs = numSongs;
            }
        } catch (Exception e) {
            System.out.println("Error creating album: " + e.getMessage());
        }
    }

    // Getter and Setter methods for title
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        try {
            this.title = title;
        } catch (Exception e) {
            System.out.println("Error setting title: " + e.getMessage());
        }
    }

    // Getter and Setter methods for performer
    public String getPerformer() {
        return performer;
    }

    public void setPerformer(String performer) {
        try {
            this.performer = performer;
        } catch (Exception e) {
            System.out.println("Error setting performer: " + e.getMessage());
        }
    }

    // Getter and Setter methods for genre
    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        try {
            // Check if the genre is valid, if not, set it to "easy listening"
            if (isValidGenre(genre)) {
                this.genre = genre;
            } else {
                this.genre = "easy listening";
            }
        } catch (Exception e) {
            System.out.println("Error setting genre: " + e.getMessage());
        }
    }

    // Getter and Setter methods for numSongs
    public int getNumSongs() {
        return numSongs;
    }

    public void setNumSongs(int numSongs) {
        try {
            // Ensure numSongs is at least 10
            if (numSongs < 10) {
                this.numSongs = 10;
            } else {
                this.numSongs = numSongs;
            }
        } catch (Exception e) {
            System.out.println("Error setting numSongs: " + e.getMessage());
        }
    }

    // Method to check if an album is long (more than 50 songs)
    public boolean isLong() {
        return numSongs > 50;
    }

    // Method to validate the genre
    private boolean isValidGenre(String genre) {
        String[] validGenres = {
                "hip-hop",
                "easy listening",
                "orchestral",
                "your parents",
                "theatre"
        };
        for (String validGenre : validGenres) {
            if (validGenre.equals(genre)) {
                return true;
            }
        }
        return false;
    }

    // toString method to display album information
    @Override
    public String toString() {
        return "Performer: " + performer + "\nTitle: " + title + "\nGenre: " + genre + "\nNumber of Songs: " + numSongs;
    }
}
