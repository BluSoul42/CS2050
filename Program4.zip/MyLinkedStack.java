import java.util.EmptyStackException;

public class MyLinkedStack {
    private Node top;
    private int size;
    private StringBuilder postfixExpression;

    public MyLinkedStack() {
        top = null;
        size = 0;
        postfixExpression = new StringBuilder();
    }

    public void push(char c) {
        Node newNode = new Node(c);
        newNode.next = top;
        top = newNode;
        size++;
    }

    public char pop() {
        if (isEmpty()) {
            throw new EmptyStackException();
        }
        char data = top.data;
        top = top.next;
        size--;
        return data;
    }

    public char peek() {
        if (isEmpty()) {
            throw new EmptyStackException();
        }
        return top.data;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public int size() {
        return size;
    }

    public String getExpression() {
        StringBuilder expressionBuilder = new StringBuilder();
        Node current = top;
        while (current != null) {
            expressionBuilder.insert(0, current.data);
            current = current.next;
        }
        return expressionBuilder.toString();
    }

    public void appendToPostfix(char c) {
        postfixExpression.append(c);
    }

    public String getPostfixExpression() {
        return postfixExpression.toString();
    }

    private class Node {
        char data;
        Node next;

        Node(char data) {
            this.data = data;
            this.next = null;
        }
    }
}
