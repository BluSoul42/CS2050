//Ivan Soto
import java.io.*;
import java.util.*;

public class Program3 {
    public static void main(String[] args) {
        try {
            new ArrayStackClass(32);

            File inputFile = new File("Program3.txt");
            Scanner scanner = new Scanner(inputFile);
            FileWriter outputFile = new FileWriter("Program3.out");

            while (scanner.hasNextLine()) {
                String infixExpression = scanner.nextLine().trim();

                if (isValidExpression(infixExpression)) {
                    String postfixExpression = InfixToPostfix(infixExpression);

                    // Add spaces between numbers and operators in the output
                    StringBuilder spacedPostfix = new StringBuilder();
                    for (char token : postfixExpression.toCharArray()) {
                        if (Character.isDigit(token) || token == '.') {
                            spacedPostfix.append(token).append(' '); // Add a space after numbers and decimal points
                        } else if (isOperator(token)) {
                            spacedPostfix.append(' ').append(token).append(' '); // Add spaces around operators
                        }
                    }

                    outputFile.write(infixExpression + " -> " + spacedPostfix.toString().trim() + "\n");
                } else {
                    // Write the infix statement to the output file unchanged with the message "invalid character"
                    outputFile.write("Unmatched parens: " + infixExpression + "\n");
                }
            }

            scanner.close();
            outputFile.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static boolean isValidExpression(String expression) {
        int openParenCount = 0;
        int closeParenCount = 0;
        for (char c : expression.toCharArray()) {
            if (c == '(') {
                openParenCount++;
            } else if (c == ')') {
                closeParenCount++;
                if (closeParenCount > openParenCount) {
                    return false; // Unmatched closing parenthesis
                }
            }
        }

        return openParenCount == closeParenCount && expression.matches("[0-9+\\-*/()% .&@–]+");
    }

    public static String InfixToPostfix(String infix) {
        StringBuilder postfix = new StringBuilder();
        ArrayStackClass operatorStack = new ArrayStackClass(infix.length());

        // Define operator precedence
        Map<Character, Integer> precedence = new HashMap<>();
        precedence.put('+', 1);
        precedence.put('-', 1);
        precedence.put('*', 2);
        precedence.put('/', 2);
        precedence.put('%', 2);

        boolean isDecimal = false; // Flag to track decimal parts

        for (char token : infix.toCharArray()) {
            if (Character.isDigit(token) || (token == '.' && !isDecimal)) {
                // If token is a digit or a decimal point (if not already a decimal)
                postfix.append(token);
                if (token == '.') {
                    isDecimal = true; // Set the flag when a decimal point is encountered
                }
            } else if (token == '(') {
                operatorStack.push(token);
            } else if (token == ')') {
                while (!operatorStack.empty() && operatorStack.peek() != '(') {
                    postfix.append(operatorStack.pop());
                }
                operatorStack.pop();
            } else if (isOperator(token)) {
                while (!operatorStack.empty() && isOperator(operatorStack.peek()) &&
                        precedence.get(token) <= precedence.get(operatorStack.peek())) {
                    postfix.append(operatorStack.pop());
                }
                operatorStack.push(token);
                isDecimal = false; // Reset the flag when an operator is encountered
            }
        }

        while (!operatorStack.empty()) {
            postfix.append(operatorStack.pop());
        }

        return postfix.toString();
    }

    // Helper method to check if a character is an operator
    private static boolean isOperator(char c) {
        return c == '+' || c == '-' || c == '*' || c == '/' || c == '%';
    }
}
