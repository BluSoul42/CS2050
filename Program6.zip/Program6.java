//Ivan Soto
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

public class Program6 {

    public static void main(String[] args) {
        // Part 1: Sorting Arrays of Integers
        int[] intArrayBubble = new int[20000];
        int[] intArraySelection = new int[20000];
        ArrayList<Integer> intArrayList = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader("NumbersInFile.txt"))) {
            String line;
            int i = 0;
            while ((line = br.readLine()) != null && i < 20000) {
                int num = Integer.parseInt(line);
                intArrayBubble[i] = num;
                intArraySelection[i] = num;
                intArrayList.add(num);
                i++;
            }
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
        }

        long bubbleSortStartTime = System.nanoTime();
        bubbleSort(intArrayBubble);
        long bubbleSortEndTime = System.nanoTime();
        long bubbleSortTime = bubbleSortEndTime - bubbleSortStartTime;

        long selectionSortStartTime = System.nanoTime();
        selectionSort(intArraySelection);
        long selectionSortEndTime = System.nanoTime();
        long selectionSortTime = selectionSortEndTime - selectionSortStartTime;

        // Part 2: Sorting Arrays of Strings and ArrayList of Strings
        String[] strArrayBubble = new String[10000];
        String[] strArraySelection = new String[10000];
        ArrayList<String> strArrayList = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader("StringsInFile.txt"))) {
            String line;
            int i = 0;
            while ((line = br.readLine()) != null && i < 10000) {
                strArrayBubble[i] = line;
                strArraySelection[i] = line;
                strArrayList.add(line);
                i++;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        long bubbleSortStrStartTime = System.nanoTime();
        bubbleSort(strArrayBubble);
        long bubbleSortStrEndTime = System.nanoTime();
        long bubbleSortStrTime = bubbleSortStrEndTime - bubbleSortStrStartTime;

        long selectionSortStrStartTime = System.nanoTime();
        selectionSort(strArraySelection);
        long selectionSortStrEndTime = System.nanoTime();
        long selectionSortStrTime = selectionSortStrEndTime - selectionSortStrStartTime;

        long collectionSortStartTime = System.nanoTime();
        Collections.sort(strArrayList);
        long collectionSortEndTime = System.nanoTime();
        long collectionSortTime = collectionSortEndTime - collectionSortStartTime;

        // Write results to a file
        try (FileWriter writer = new FileWriter("results.txt")) {
            writer.write("Bubble Sort Time (Integers): " + bubbleSortTime + " ns\n");
            writer.write("Selection Sort Time (Integers): " + selectionSortTime + " ns\n\n");

            writer.write("Bubble Sort Time (Strings): " + bubbleSortStrTime + " ns\n");
            writer.write("Selection Sort Time (Strings): " + selectionSortStrTime + " ns\n");
            writer.write("Collection Sort Time (Strings): " + collectionSortTime + " ns\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Bubble Sort for integers
    private static void bubbleSort(int[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (arr[j] > arr[j + 1]) {
                    // swap temp and arr[i]
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }

    // Bubble Sort for strings
    private static void bubbleSort(String[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (arr[j].compareTo(arr[j + 1]) > 0) {
                    // swap temp and arr[i]
                    String temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }

    // Selection Sort for integers
    private static void selectionSort(int[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < n; j++) {
                if (arr[j] < arr[minIndex]) {
                    minIndex = j;
                }
            }
            // swap temp and arr[i]
            int temp = arr[minIndex];
            arr[minIndex] = arr[i];
            arr[i] = temp;
        }
    }

    // Selection Sort for strings
    private static void selectionSort(String[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < n; j++) {
                if (arr[j].compareTo(arr[minIndex]) < 0) {
                    minIndex = j;
                }
            }
            // swap temp and arr[i]
            String temp = arr[minIndex];
            arr[minIndex] = arr[i];
            arr[i] = temp;
        }
    }
}
