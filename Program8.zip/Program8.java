//Ivan Soto
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

class TreeNode {
    String data;
    TreeNode left, right;

    public TreeNode(String word) {
        this.data = word;
        this.left = this.right = null;
    }
}

class BST {
    private TreeNode root;

    public BST() {
        this.root = null;
    }

    public void insert(String word) {
        if (word == null || word.isEmpty() || !word.matches("[a-zA-Z]+")) {
            // Ignore empty strings, null, or strings containing non-alphabetic characters
            return;
        }
        word = word.toLowerCase();
        root = insertRec(root, word);
    }

    private TreeNode insertRec(TreeNode root, String word) {
        if (root == null) {
            return new TreeNode(word);
        }

        int compareResult = word.compareTo(root.data);

        if (compareResult < 0) {
            root.left = insertRec(root.left, word);
        } else if (compareResult > 0) {
            root.right = insertRec(root.right, word);
        }

        return root;
    }

    public void postOrderTraversal(TreeNode root, FileWriter writer) throws IOException {
        if (root != null) {
            postOrderTraversal(root.left, writer);
            postOrderTraversal(root.right, writer);
            writer.write(root.data + "\n");
        }
    }

    public void analyzeTree() {
        int nodeCount = countNodes(root);
        int treeHeight = calculateHeight(root);
        int maxNodes = (int) Math.pow(2, treeHeight) - 1;

        try (FileWriter writer = new FileWriter("analysis.txt")) {
            writer.write("Number of nodes: " + nodeCount + "\n");
            writer.write("Tree height: " + treeHeight + "\n");
            writer.write("Max possible nodes: " + maxNodes + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private int countNodes(TreeNode root) {
        if (root == null) {
            return 0;
        }
        return 1 + countNodes(root.left) + countNodes(root.right);
    }

    private int calculateHeight(TreeNode root) {
        if (root == null) {
            return 0;
        }
        int leftHeight = calculateHeight(root.left);
        int rightHeight = calculateHeight(root.right);

        return 1 + Math.max(leftHeight, rightHeight);
    }
}

public class Program8 {
    public static void main(String[] args) {
        try (BufferedReader reader = new BufferedReader(new FileReader("dracula.txt"))) {
            String line;
            BST bst = new BST();

            while ((line = reader.readLine()) != null) {
                String[] words = line.split("\\s+");

                for (String word : words) {
                    word = word.replaceAll("[^a-zA-Z']", ""); // Remove non-alphabetic characters
                    bst.insert(word);
                }
            }

            bst.analyzeTree();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
