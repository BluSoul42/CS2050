/*
 * Your name: Ivan Soto
 * Description: Program2
 */


public class Program2 {

    // TODO #1: finish the method's implementation
    public static double add(double a, double b) {
        return a + b;
    }

    // TODO #2: finish the method's implementation
    public static double subtract(double a, double b) {
        return a - b;
    }

    // TODO #3: finish the method's implementation
    public static double multiply(double a, double b) {
        if (a * b == -0) {
            return Math.abs(a * b);
        }
        else {
            return a * b;
        }
    }

    // TODO #4: finish the method's implementation
    public static double divide(double a, double b) {
        if (b == 0) {
            throw new ArithmeticException("Division by zero");
        }
        return a / b;
    }

    // TODO #5: finish the method's implementation - assume right triangle
    public static double sinOfAngle(double oppSide, double hyp) {
        if (hyp == 0) {
            throw new IllegalArgumentException("Hypotenuse must be greater than zero");
        }
        double result = oppSide / hyp;
        return roundToTwoDecimalPlaces(result);
    }

    // TODO #6: finish the method's implementation - assume right triangle
    public static double hypOfTriangle(double sideA, double sideB) {
        if (sideA <= 0 || sideB <= 0) {
            throw new IllegalArgumentException("Side lengths must be greater than zero");
        }
        double result = Math.sqrt(sideA * sideA + sideB * sideB);
        return roundToTwoDecimalPlaces(result);
    }

    private static double roundToTwoDecimalPlaces(double value) {
        return Math.round(value * 100.0) / 100.0; // Round to two decimal places
    }

    // Helper method to run methods and return results
    public static double[] runMethods(double a, double b, double oppSide, double hyp) {
        double[] results = new double[6];
        try {
            results[0] = add(a, b);
            results[1] = subtract(a, b);
            results[2] = multiply(a, b);
            results[3] = divide(a, b);
            results[4] = sinOfAngle(oppSide, hyp);
            results[5] = hypOfTriangle(a, b);
        } catch (ArithmeticException e) {
            System.err.println("ArithmeticException: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            System.err.println("IllegalArgumentException: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("An unexpected error occurred: " + e.getMessage());
        }
        return results;
    }

    public static void main(String[] args) {
        double a = 5.0;
        double b = 2.0;
        double oppSide = 3.0;
        double hyp = 4.1;

        // Call the helper method to run methods and return results
        double[] results = runMethods(a, b, oppSide, hyp);

        // Print the results
        System.out.println("Results:");
        System.out.println("Addition: " + results[0]);
        System.out.println("Subtraction: " + results[1]);
        System.out.println("Multiplication: " + results[2]);
        System.out.println("Division: " + results[3]);
        System.out.println("sinOfAngle: " + results[4]);
        System.out.println("hypOfTriangle: " + results[5]);
    }
}
