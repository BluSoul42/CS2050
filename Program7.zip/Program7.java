//Ivan Soto
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

public class Program7 {

    public static void main(String[] args) {
        // Part 1: Sorting Arrays of Integers
        int[] intArrayBubble = new int[20000];
        int[] intArraySelection = new int[20000];
        int[] intArrayInsertion = new int[20000];
        ArrayList<Integer> intArrayList = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\ivans\\IdeaProjects\\Program7\\NumbersInFile.txt"))) {
            String line;
            int i = 0;
            while ((line = br.readLine()) != null && i < 20000) {
                int num = Integer.parseInt(line);
                intArrayBubble[i] = num;
                intArraySelection[i] = num;
                intArrayInsertion[i] = num;
                intArrayList.add(num);
                i++;
            }
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
        }

        // Bubble Sort
        long bubbleSortStartTime = System.nanoTime();
        bubbleSort(intArrayBubble);
        long bubbleSortEndTime = System.nanoTime();
        long bubbleSortTime = bubbleSortEndTime - bubbleSortStartTime;

        // Selection Sort
        long selectionSortStartTime = System.nanoTime();
        selectionSort(intArraySelection);
        long selectionSortEndTime = System.nanoTime();
        long selectionSortTime = selectionSortEndTime - selectionSortStartTime;

        // Insertion Sort
        long insertionSortStartTime = System.nanoTime();
        insertionSort(intArrayInsertion);
        long insertionSortEndTime = System.nanoTime();
        long insertionSortTime = insertionSortEndTime - insertionSortStartTime;

        // Part 2: Sorting Arrays of Strings
        String[] strArrayBubble = new String[10000];
        String[] strArraySelection = new String[10000];
        String[] strArrayInsertion = new String[10000];
        ArrayList<String> strArrayList = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\ivans\\IdeaProjects\\Program7\\StringsInFIle"))) {
            String line;
            int i = 0;
            while ((line = br.readLine()) != null && i < 10000) {
                strArrayBubble[i] = line;
                strArraySelection[i] = line;
                strArrayInsertion[i] = line;
                strArrayList.add(line);
                i++;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Bubble Sort for Strings
        long bubbleSortStrStartTime = System.nanoTime();
        bubbleSort(strArrayBubble);
        long bubbleSortStrEndTime = System.nanoTime();
        long bubbleSortStrTime = bubbleSortStrEndTime - bubbleSortStrStartTime;

        // Selection Sort for Strings
        long selectionSortStrStartTime = System.nanoTime();
        selectionSort(strArraySelection);
        long selectionSortStrEndTime = System.nanoTime();
        long selectionSortStrTime = selectionSortStrEndTime - selectionSortStrStartTime;

        // Insertion Sort for Strings
        long insertionSortStrStartTime = System.nanoTime();
        insertionSort(strArrayInsertion);
        long insertionSortStrEndTime = System.nanoTime();
        long insertionSortStrTime = insertionSortStrEndTime - insertionSortStrStartTime;

        // Collection Sort for Strings
        long collectionSortStartTime = System.nanoTime();
        Collections.sort(strArrayList);
        long collectionSortEndTime = System.nanoTime();
        long collectionSortTime = collectionSortEndTime - collectionSortStartTime;

        // Write results to a file
        try (FileWriter writer = new FileWriter("results.txt")) {
            writer.write("Number of integers: 20000\n");
            writer.write("Bubble Sort Time (Integers): " + bubbleSortTime + " ns\n");
            writer.write("Selection Sort Time (Integers): " + selectionSortTime + " ns\n");
            writer.write("Insertion Sort Time (Integers): " + insertionSortTime + " ns\n\n");

            writer.write("Number of strings: 10000\n");
            writer.write("Bubble Sort Time (Strings): " + bubbleSortStrTime + " ns\n");
            writer.write("Selection Sort Time (Strings): " + selectionSortStrTime + " ns\n");
            writer.write("Insertion Sort Time (Strings): " + insertionSortStrTime + " ns\n");
            writer.write("Collection Sort Time (Strings): " + collectionSortTime + " ns\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Bubble Sort for integers
    private static void bubbleSort(int[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (arr[j] > arr[j + 1]) {
                    // swap temp and arr[i]
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }

    // Selection Sort for integers
    private static void selectionSort(int[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < n; j++) {
                if (arr[j] < arr[minIndex]) {
                    minIndex = j;
                }
            }
            // swap temp and arr[i]
            int temp = arr[minIndex];
            arr[minIndex] = arr[i];
            arr[i] = temp;
        }
    }

    // Insertion Sort for integers
    private static void insertionSort(int[] arr) {
        int n = arr.length;
        for (int i = 1; i < n; ++i) {
            int key = arr[i];
            int j = i - 1;

            while (j >= 0 && arr[j] > key) {
                arr[j + 1] = arr[j];
                j = j - 1;
            }
            arr[j + 1] = key;
        }
    }

    // Bubble Sort for strings
    private static void bubbleSort(String[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (arr[j].compareTo(arr[j + 1]) > 0) {
                    // swap temp and arr[i]
                    String temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }

    // Selection Sort for strings
    private static void selectionSort(String[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < n; j++) {
                if (arr[j].compareTo(arr[minIndex]) < 0) {
                    minIndex = j;
                }
            }
            // swap temp and arr[i]
            String temp = arr[minIndex];
            arr[minIndex] = arr[i];
            arr[i] = temp;
        }
    }

    // Insertion Sort for strings
    private static void insertionSort(String[] arr) {
        int n = arr.length;
        for (int i = 1; i < n; ++i) {
            String key = arr[i];
            int j = i - 1;

            while (j >= 0 && arr[j].compareTo(key) > 0) {
                arr[j + 1] = arr[j];
                j = j - 1;
            }
            arr[j + 1] = key;
        }
    }
}